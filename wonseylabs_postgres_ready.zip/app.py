
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime
import sqlite3, os, json
try:
    import psycopg
    from psycopg.rows import dict_row
except Exception:
    psycopg = None

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
DB_PATH = os.environ.get("DATABASE_PATH", "wonseylabs.db")

class PGCursor:
    def __init__(self, cur):
        self.cur = cur
    def fetchone(self):
        return self.cur.fetchone()
    def fetchall(self):
        return self.cur.fetchall()

class PGConn:
    def __init__(self, conn):
        self.conn = conn
    def execute(self, sql, params=()):
        sql = sql.replace("?", "%s")
        cur = self.conn.cursor()
        cur.execute(sql, params)
        return PGCursor(cur)
    def executescript(self, script):
        cur = self.conn.cursor()
        for stmt in script.split(";"):
            if stmt.strip():
                cur.execute(stmt)
    def commit(self):
        self.conn.commit()
    def close(self):
        self.conn.close()

def using_postgres():
    return bool(DATABASE_URL)

def get_db():
    if using_postgres():
        if psycopg is None:
            raise RuntimeError("DATABASE_URL is set but psycopg is not installed.")
        conn = psycopg.connect(DATABASE_URL, row_factory=dict_row)
        return PGConn(conn)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

FACULTIES = [
    ("Peter","Faith","What am I believing?"),
    ("Andrew","Strength / Courage","What would courage do next?"),
    ("James","Judgment / Wisdom","What is actually true?"),
    ("John","Love","What response preserves truth and love?"),
    ("Philip","Word","What am I speaking?"),
    ("Bartholomew","Imagination","What image am I rehearsing?"),
    ("Thomas","Understanding","What do I not yet understand?"),
    ("Matthew","Will","What will I finish?"),
    ("James the Less","Order / Discipline","What comes first?"),
    ("Simon","Zeal","What deserves my energy?"),
    ("Judas","Detachment / Right Valuation","What am I overvaluing?"),
    ("Thaddeus","Praise","What good have I failed to notice?")
]

SECTORS = [
    "Self / Identity","Thought","Emotion","Spiritual","Faculty","Body / Health",
    "Relationships","Time / Attention","Environment","Money / Resources",
    "Work / Purpose","Digital / Media","Consequence","Opportunity","Community / World"
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    if using_postgres():
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id BIGSERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'member',
            goal TEXT DEFAULT '',
            focus TEXT DEFAULT '',
            share_general INTEGER DEFAULT 0,
            share_health INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS experiments(
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            question TEXT DEFAULT '',
            practice TEXT DEFAULT '',
            metric TEXT DEFAULT '',
            duration_days INTEGER DEFAULT 30,
            status TEXT DEFAULT 'active',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS entries(
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            experiment_id BIGINT,
            entry_type TEXT NOT NULL DEFAULT 'journal',
            title TEXT DEFAULT '',
            before_text TEXT DEFAULT '',
            after_text TEXT DEFAULT '',
            awareness INTEGER DEFAULT 5,
            discipline INTEGER DEFAULT 5,
            energy INTEGER DEFAULT 5,
            focus INTEGER DEFAULT 5,
            sleep INTEGER DEFAULT 5,
            confidence INTEGER DEFAULT 5,
            coach_help TEXT DEFAULT '',
            health_related INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS faculty_logs(
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            faculty TEXT NOT NULL,
            disciple TEXT NOT NULL,
            response TEXT DEFAULT '',
            score INTEGER DEFAULT 5,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS awareness_scans(
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL,
            data_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS coach_notes(
            id BIGSERIAL PRIMARY KEY,
            coach_id BIGINT NOT NULL,
            member_id BIGINT NOT NULL,
            note TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
    else:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'member',
            goal TEXT DEFAULT '',
            focus TEXT DEFAULT '',
            share_general INTEGER DEFAULT 0,
            share_health INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS experiments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            question TEXT DEFAULT '',
            practice TEXT DEFAULT '',
            metric TEXT DEFAULT '',
            duration_days INTEGER DEFAULT 30,
            status TEXT DEFAULT 'active',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            experiment_id INTEGER,
            entry_type TEXT NOT NULL DEFAULT 'journal',
            title TEXT DEFAULT '',
            before_text TEXT DEFAULT '',
            after_text TEXT DEFAULT '',
            awareness INTEGER DEFAULT 5,
            discipline INTEGER DEFAULT 5,
            energy INTEGER DEFAULT 5,
            focus INTEGER DEFAULT 5,
            sleep INTEGER DEFAULT 5,
            confidence INTEGER DEFAULT 5,
            coach_help TEXT DEFAULT '',
            health_related INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS faculty_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            faculty TEXT NOT NULL,
            disciple TEXT NOT NULL,
            response TEXT DEFAULT '',
            score INTEGER DEFAULT 5,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS awareness_scans(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            data_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS coach_notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            coach_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            note TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
    coach = conn.execute("SELECT id FROM users WHERE role='coach' LIMIT 1").fetchone()
    if not coach:
        conn.execute(
            "INSERT INTO users(name,email,password_hash,role,goal,focus,share_general,share_health,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            ("Wonsey Labs Coach","coach@wonseylabs.org",generate_password_hash("ChangeMe123!"),"coach",
             "Help members observe patterns and choose the next experiment","Coach Console",1,1,datetime.utcnow().isoformat())
        )
    conn.commit()
    conn.close()

@app.before_request
def ensure_db():
    init_db()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def coach_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        conn = get_db()
        u = conn.execute("SELECT role FROM users WHERE id=?", (session["user_id"],)).fetchone()
        conn.close()
        if not u or u["role"] != "coach":
            flash("Coach access required.")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapped

def current_user():
    if "user_id" not in session:
        return None
    conn = get_db()
    u = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return u

@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "FACULTIES": FACULTIES, "SECTORS": SECTORS}

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        goal = request.form.get("goal","").strip()
        focus = request.form.get("focus","Awareness").strip()
        if not name or not email or len(password) < 8:
            flash("Enter a name, email, and password of at least 8 characters.")
            return redirect(url_for("register"))
        conn = get_db()
        try:
            if using_postgres():
                row = conn.execute(
                    "INSERT INTO users(name,email,password_hash,role,goal,focus,created_at) VALUES(?,?,?,?,?,?,?) RETURNING id",
                    (name,email,generate_password_hash(password),"member",goal,focus,datetime.utcnow().isoformat())
                ).fetchone()
                conn.commit()
                session["user_id"] = row["id"]
            else:
                cur = conn.execute(
                    "INSERT INTO users(name,email,password_hash,role,goal,focus,created_at) VALUES(?,?,?,?,?,?,?)",
                    (name,email,generate_password_hash(password),"member",goal,focus,datetime.utcnow().isoformat())
                )
                conn.commit()
                session["user_id"] = cur.lastrowid
            flash("Welcome to Wonsey Labs.")
            return redirect(url_for("dashboard"))
        except Exception as e:
            if using_postgres() and psycopg and isinstance(e, psycopg.IntegrityError):
                pass
            elif not using_postgres() and isinstance(e, sqlite3.IntegrityError):
                pass
            else:
                raise
            flash("That email is already registered.")
            return redirect(url_for("register"))
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        conn = get_db()
        u = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if u and check_password_hash(u["password_hash"], password):
            session["user_id"] = u["id"]
            return redirect(url_for("coach") if u["role"]=="coach" else url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    u = current_user()
    if u["role"] == "coach":
        return redirect(url_for("coach"))
    conn = get_db()
    exps = conn.execute("SELECT * FROM experiments WHERE user_id=? ORDER BY id DESC",(u["id"],)).fetchall()
    entries = conn.execute("SELECT * FROM entries WHERE user_id=? ORDER BY id DESC LIMIT 8",(u["id"],)).fetchall()
    f_logs = conn.execute("SELECT * FROM faculty_logs WHERE user_id=? ORDER BY id DESC LIMIT 12",(u["id"],)).fetchall()
    latest = conn.execute("SELECT * FROM entries WHERE user_id=? ORDER BY id DESC LIMIT 1",(u["id"],)).fetchone()
    conn.close()
    return render_template("dashboard.html", user=u, experiments=exps, entries=entries, faculty_logs=f_logs, latest=latest)

@app.route("/settings", methods=["POST"])
@login_required
def settings():
    u = current_user()
    conn = get_db()
    conn.execute("UPDATE users SET share_general=?,share_health=?,goal=?,focus=? WHERE id=?",
        (1 if request.form.get("share_general") else 0,
         1 if request.form.get("share_health") else 0,
         request.form.get("goal","").strip(),
         request.form.get("focus","").strip(), u["id"]))
    conn.commit()
    conn.close()
    flash("Sharing settings updated.")
    return redirect(url_for("dashboard"))

@app.route("/experiment/new", methods=["POST"])
@login_required
def new_experiment():
    u = current_user()
    conn = get_db()
    conn.execute("""INSERT INTO experiments(user_id,name,category,question,practice,metric,duration_days,created_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
        (u["id"],request.form["name"].strip(),request.form["category"],
         request.form.get("question","").strip(),request.form.get("practice","").strip(),
         request.form.get("metric","").strip(),int(request.form.get("duration_days",30)),
         datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    flash("Personal Lab activated.")
    return redirect(url_for("dashboard"))

@app.route("/entry/new", methods=["POST"])
@login_required
def new_entry():
    u = current_user()
    conn = get_db()
    conn.execute("""INSERT INTO entries(user_id,experiment_id,entry_type,title,before_text,after_text,
                    awareness,discipline,energy,focus,sleep,confidence,coach_help,health_related,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (u["id"],request.form.get("experiment_id") or None,"journal",
         request.form.get("title","").strip(),request.form.get("before_text","").strip(),
         request.form.get("after_text","").strip(),int(request.form.get("awareness",5)),
         int(request.form.get("discipline",5)),int(request.form.get("energy",5)),
         int(request.form.get("focus",5)),int(request.form.get("sleep",5)),
         int(request.form.get("confidence",5)),request.form.get("coach_help","").strip(),
         1 if request.form.get("health_related") else 0,datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    flash("Lab observation recorded.")
    return redirect(url_for("dashboard"))

@app.route("/faculty/<disciple>/<faculty>", methods=["GET","POST"])
@login_required
def faculty_lab(disciple, faculty):
    prompt = next((x[2] for x in FACULTIES if x[0]==disciple), "What do you notice?")
    if request.method == "POST":
        u = current_user()
        conn = get_db()
        conn.execute("INSERT INTO faculty_logs(user_id,faculty,disciple,response,score,created_at) VALUES(?,?,?,?,?,?)",
            (u["id"],faculty,disciple,request.form.get("response","").strip(),
             int(request.form.get("score",5)),datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        flash(f"{faculty} observation saved.")
        return redirect(url_for("dashboard"))
    return render_template("faculty.html", disciple=disciple, faculty=faculty, prompt=prompt)

@app.route("/awareness", methods=["GET","POST"])
@login_required
def awareness():
    if request.method == "POST":
        u = current_user()
        data = {}
        for sector in SECTORS:
            key = sector.replace("/","_").replace(" ","_")
            data[sector] = {"score":int(request.form.get(key+"_score",3)),
                            "note":request.form.get(key+"_note","").strip()}
        conn = get_db()
        conn.execute("INSERT INTO awareness_scans(user_id,data_json,created_at) VALUES(?,?,?)",
            (u["id"],json.dumps(data),datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        flash("Awareness scan saved.")
        return redirect(url_for("dashboard"))
    return render_template("awareness.html")

@app.route("/coach")
@coach_required
def coach():
    conn = get_db()
    members = conn.execute("SELECT * FROM users WHERE role='member' ORDER BY created_at DESC").fetchall()
    rows = []
    for m in members:
        latest = conn.execute("SELECT * FROM entries WHERE user_id=? ORDER BY id DESC LIMIT 1",(m["id"],)).fetchone()
        active = conn.execute("SELECT COUNT(*) c FROM experiments WHERE user_id=? AND status='active'",(m["id"],)).fetchone()["c"]
        rows.append({"member":m,"latest":latest,"active_count":active})
    conn.close()
    return render_template("coach.html", rows=rows)

@app.route("/coach/member/<int:member_id>", methods=["GET","POST"])
@coach_required
def coach_member(member_id):
    coach_user = current_user()
    conn = get_db()
    m = conn.execute("SELECT * FROM users WHERE id=? AND role='member'",(member_id,)).fetchone()
    if not m:
        conn.close()
        return "Member not found",404
    if request.method == "POST":
        note = request.form.get("note","").strip()
        if note:
            conn.execute("INSERT INTO coach_notes(coach_id,member_id,note,created_at) VALUES(?,?,?,?)",
                (coach_user["id"],member_id,note,datetime.utcnow().isoformat()))
            conn.commit()
        conn.close()
        flash("Coach note saved.")
        return redirect(url_for("coach_member",member_id=member_id))

    experiments = conn.execute("SELECT * FROM experiments WHERE user_id=? ORDER BY id DESC",(member_id,)).fetchall() if m["share_general"] else []
    entries = conn.execute("SELECT * FROM entries WHERE user_id=? ORDER BY id DESC LIMIT 30",(member_id,)).fetchall() if m["share_general"] else []
    faculty_logs = conn.execute("SELECT * FROM faculty_logs WHERE user_id=? ORDER BY id DESC LIMIT 24",(member_id,)).fetchall() if m["share_general"] else []
    notes = conn.execute("SELECT * FROM coach_notes WHERE member_id=? ORDER BY id DESC",(member_id,)).fetchall()
    conn.close()
    if m["share_general"] and not m["share_health"]:
        entries = [e for e in entries if not e["health_related"]]
    return render_template("coach_member.html", member=m, experiments=experiments, entries=entries, faculty_logs=faculty_logs, notes=notes)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=True)
