# Wonsey Labs — Full-Stack Membership + Coach Console

This build adds real local accounts, password hashing, a persistent SQLite database, member-controlled sharing, personal labs, awareness scans, faculty training logs, client responses, and a coach console.

## Run
1. `pip install -r requirements.txt`
2. `python app.py`
3. Open `http://localhost:5000`

The database initializes automatically.

### Initial coach account
- Email: coach@wonseylabs.org
- Password: ChangeMe123!

Change the coach password/auth setup and SECRET_KEY before public deployment.

## Production hardening before real client use
Use managed Postgres, HTTPS, secure cookies, CSRF protection, rate limiting, email verification/password reset, encrypted backups, audit logs, explicit coach-member authorization, account deletion/export tools, and reviewed privacy/consent policies. If you plan to store sensitive health information, get appropriate legal/security guidance before launch.
